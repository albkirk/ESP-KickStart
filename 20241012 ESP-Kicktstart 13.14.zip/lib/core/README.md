The goal is to **NOT CHANGE** any of these files for your specific project.

If you really need to change them, it's likely that you need to update this template! :smile:
 
