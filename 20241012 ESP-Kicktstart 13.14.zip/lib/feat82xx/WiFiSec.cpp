#ifdef ESP8266

#include <WiFiSec.h>

// Connect to WiFi network.
void WiFiSec::SecDummy()
    {
        yield();
}

#endif